# Sodi mark

The mark is a document with some lines redacted, arranged so the remaining
bars read as an S. Ten rows on a fixed rhythm; each row is a short upper strip
(3.2 units) over a wider lower strip (4 units), pitch 10.4, artboard 100 x 100.8.
All geometry is on a 0.5-unit grid and every bar is a single path, so the files
scale to any size and animate cleanly.

Files
- sodi-mark-tonal.svg          master, transparent background, four greys
- sodi-mark-tonal-dark.svg     same on #0A0C0B
- sodi-mark-tonal-light.svg    inverted tones on #F2F3F0
- sodi-mark-mono-light.svg     one colour (#EDEBE4) for dark backgrounds
- sodi-mark-mono-dark.svg      one colour (#121412) for light backgrounds
- sodi-icon-dark.svg           128px app icon, rounded 24, dark
- sodi-icon-light.svg          128px app icon, rounded 24, light
- sodi-favicon.svg             four-row reduction on a 32px grid, for 24-64px
- sodi-favicon-16.svg          the same four rows snapped to a 16px grid, for 16px
- favicon.ico                  16 (from the 16px grid), 32 and 48
- png/                         apple-touch-icon 180, icon-192, icon-512 (+ light),
                               favicon-16/32/48, tonal mark at 1024

Tones (dark theme): #EDEBE4, #D0CEC6, #B9B5AF, #A19F98
Tones (light theme): #121412, #3A3C38, #5A5D58, #7A7D78
Backgrounds: #0A0C0B dark, #F2F3F0 light. Accent #7FB69B is never used in the mark.

Rules
- Use the mono versions in the nav and anywhere the mark sits beside text.
- Use tonal versions only at 64px and above.
- Below 64px use the favicon, not a scaled-down icon: ten rows turn to mush.
  The favicon keeps the idea in four rows: top arm (step at right), left
  spine, right spine, bottom arm (step at left). Every row keeps the stepped
  upper/lower strip, with the longer strip on the inside of the S as in the
  master. Edges land on whole pixels at 16 and 32, so nothing blurs.
- The favicon is one tone. Tonal greys don't survive at 16px.
- It is not a substitute for the mark elsewhere.

Web
  <link rel="icon" href="/favicon.ico" sizes="48x48">
  <link rel="icon" href="/sodi-favicon.svg" type="image/svg+xml">
  <link rel="apple-touch-icon" href="/apple-touch-icon.png">
- Keep the mark one hue. Depth comes from the tone scale, not colour.
